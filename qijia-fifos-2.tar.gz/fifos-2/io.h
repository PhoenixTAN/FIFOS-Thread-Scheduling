#ifndef IO_H
#define IO_H

void clear(void);
void printc(char);
void printd(unsigned);
void printl(unsigned);
void prints(char *);

#endif
